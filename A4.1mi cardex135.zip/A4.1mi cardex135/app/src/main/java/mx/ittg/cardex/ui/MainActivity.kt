package mx.ittg.cardex.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import mx.ittg.cardex.R
import mx.ittg.cardex.data.Sesion
import mx.ittg.cardex.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Primera vez: pedir nombre y número de control
        if (!Sesion.registrado(this)) {
            startActivity(Intent(this, PerfilActivity::class.java))
            finish()
            return
        }

        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        setSupportActionBar(b.toolbar)
        supportActionBar?.title = "Mi Cardex"

        b.bottomNav.setOnItemSelectedListener { item ->
            val fragmento = when (item.itemId) {
                R.id.nav_materias -> ListaFragment()
                else -> PromediosFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.contenedor, fragmento)
                .commit()
            true
        }
        if (savedInstanceState == null) b.bottomNav.selectedItemId = R.id.nav_materias
    }

    override fun onResume() {
        super.onResume()
        if (::b.isInitialized) {
            supportActionBar?.subtitle = "${Sesion.nombre(this)} · ${Sesion.control(this)}"
        }
    }
}
