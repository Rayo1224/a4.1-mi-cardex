package mx.ittg.cardex.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Asignatura::class], version = 1, exportSchema = false)
abstract class CardexDb : RoomDatabase() {
    abstract fun asignaturas(): AsignaturaDao

    companion object {
        @Volatile private var instancia: CardexDb? = null

        fun obtener(contexto: Context): CardexDb = instancia ?: synchronized(this) {
            instancia ?: Room.databaseBuilder(
                contexto.applicationContext, CardexDb::class.java, "mi_cardex.db"
            ).build().also { instancia = it }
        }
    }
}
