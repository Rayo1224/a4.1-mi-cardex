package mx.ittg.cardex.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import mx.ittg.cardex.databinding.FragmentPromediosBinding
import mx.ittg.cardex.databinding.ItemPromedioBinding

class PromediosFragment : Fragment() {

    private var _b: FragmentPromediosBinding? = null
    private val b get() = _b!!
    private val vm: CardexViewModel by activityViewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        _b = FragmentPromediosBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        vm.promedioGeneral.observe(viewLifecycleOwner) {
            b.txtGeneral.text = formatoNota(it, 2)
        }

        vm.promediosSemestre.observe(viewLifecycleOwner) { lista ->
            b.contenedorSemestres.removeAllViews()
            b.sinDatos.isVisible = lista.isEmpty()
            lista.forEach { ps ->
                val fila = ItemPromedioBinding.inflate(layoutInflater, b.contenedorSemestres, false)
                fila.txtSem.text = "Semestre ${ps.semestre}"
                fila.txtProm.text = formatoNota(ps.promedio, 2)
                b.contenedorSemestres.addView(fila.root)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}
