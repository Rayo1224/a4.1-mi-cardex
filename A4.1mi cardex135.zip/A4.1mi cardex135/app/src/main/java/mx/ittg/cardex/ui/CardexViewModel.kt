package mx.ittg.cardex.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import mx.ittg.cardex.data.Asignatura
import mx.ittg.cardex.data.AsignaturaRepository
import mx.ittg.cardex.data.CardexDb
import mx.ittg.cardex.data.PromSem

class CardexViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AsignaturaRepository(CardexDb.obtener(app).asignaturas())

    val promedioGeneral: LiveData<Double?> = repo.promedioGeneral
    val promediosSemestre: LiveData<List<PromSem>> = repo.promediosSemestre

    /** Lista de la pantalla: un encabezado por semestre (con su promedio) y sus asignaturas. */
    val filas = MediatorLiveData<List<FilaCardex>>()

    init {
        filas.addSource(repo.asignaturas) { combinar() }
        filas.addSource(repo.promediosSemestre) { combinar() }
    }

    private fun combinar() {
        val lista = repo.asignaturas.value ?: return
        val prom = repo.promediosSemestre.value.orEmpty().associate { it.semestre to it.promedio }
        filas.value = lista.groupBy { it.semestre }.flatMap { (sem, materias) ->
            listOf<FilaCardex>(FilaCardex.Encabezado(sem, prom[sem])) + materias.map { FilaCardex.Materia(it) }
        }
    }

    fun guardar(a: Asignatura) = viewModelScope.launch { repo.guardar(a) }

    fun borrar(a: Asignatura) = viewModelScope.launch { repo.borrar(a) }
}
