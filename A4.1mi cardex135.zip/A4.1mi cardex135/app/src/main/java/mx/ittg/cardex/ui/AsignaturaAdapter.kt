package mx.ittg.cardex.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import mx.ittg.cardex.data.Asignatura
import mx.ittg.cardex.databinding.ItemAsignaturaBinding
import mx.ittg.cardex.databinding.ItemSemestreBinding
import java.util.Locale

fun formatoNota(d: Double?, decimales: Int = 1): String =
    d?.let { String.format(Locale.US, "%.${decimales}f", it) } ?: "—"

/** Filas de la lista: un encabezado por semestre (con su promedio) y las asignaturas de ese semestre. */
sealed interface FilaCardex {
    data class Encabezado(val semestre: Int, val promedio: Double?) : FilaCardex
    data class Materia(val asignatura: Asignatura) : FilaCardex
}

class AsignaturaAdapter(
    private val alTocar: (Asignatura) -> Unit,
    private val alMantener: (Asignatura) -> Unit
) : ListAdapter<FilaCardex, RecyclerView.ViewHolder>(Diff) {

    class VHSemestre(val b: ItemSemestreBinding) : RecyclerView.ViewHolder(b.root)
    class VHMateria(val b: ItemAsignaturaBinding) : RecyclerView.ViewHolder(b.root)

    object Diff : DiffUtil.ItemCallback<FilaCardex>() {
        override fun areItemsTheSame(a: FilaCardex, b: FilaCardex) = when {
            a is FilaCardex.Encabezado && b is FilaCardex.Encabezado -> a.semestre == b.semestre
            a is FilaCardex.Materia && b is FilaCardex.Materia -> a.asignatura.id == b.asignatura.id
            else -> false
        }
        override fun areContentsTheSame(a: FilaCardex, b: FilaCardex) = a == b
    }

    override fun getItemViewType(position: Int) =
        if (getItem(position) is FilaCardex.Encabezado) TIPO_SEMESTRE else TIPO_MATERIA

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TIPO_SEMESTRE) VHSemestre(ItemSemestreBinding.inflate(inflater, parent, false))
        else VHMateria(ItemAsignaturaBinding.inflate(inflater, parent, false))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val fila = getItem(position)) {
            is FilaCardex.Encabezado -> (holder as VHSemestre).b.apply {
                txtTituloSem.text = "Semestre ${fila.semestre}"
                txtPromSem.text = "Promedio: ${formatoNota(fila.promedio, 2)}"
            }
            is FilaCardex.Materia -> (holder as VHMateria).b.apply {
                val a = fila.asignatura
                txtNombre.text = a.nombre
                txtSemestre.text = "Semestre ${a.semestre}"
                txtOportunidades.text =
                    "Normal ${formatoNota(a.normal)}  |  Repetición ${formatoNota(a.repeticion)}  |  Especial ${formatoNota(a.especial)}"
                txtFinal.text = formatoNota(a.vigente())
                root.setOnClickListener { alTocar(a) }
                root.setOnLongClickListener { alMantener(a); true }
            }
        }
    }

    private companion object {
        const val TIPO_SEMESTRE = 0
        const val TIPO_MATERIA = 1
    }
}
