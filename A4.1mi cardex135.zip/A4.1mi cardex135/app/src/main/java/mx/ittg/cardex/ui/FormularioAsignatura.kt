package mx.ittg.cardex.ui

import android.content.Context
import android.content.DialogInterface
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import mx.ittg.cardex.data.Asignatura
import mx.ittg.cardex.databinding.DialogAsignaturaBinding

/** Cuadro de diálogo para capturar o editar una asignatura. */
object FormularioAsignatura {

    private fun leerNota(t: String): Double? = t.trim().replace(',', '.').toDoubleOrNull()
    private fun notaValida(t: String) = t.isBlank() || leerNota(t)?.let { it in 0.0..100.0 } == true

    fun mostrar(
        contexto: Context,
        inflater: LayoutInflater,
        actual: Asignatura?,
        alGuardar: (Asignatura) -> Unit
    ) {
        val d = DialogAsignaturaBinding.inflate(inflater)
        d.menuSemestre.setAdapter(
            ArrayAdapter(contexto, android.R.layout.simple_list_item_1, (1..12).map { it.toString() })
        )
        actual?.let {
            d.etNombre.setText(it.nombre)
            d.menuSemestre.setText(it.semestre.toString(), false)
            d.etNormal.setText(it.normal?.toString().orEmpty())
            d.etRepeticion.setText(it.repeticion?.toString().orEmpty())
            d.etEspecial.setText(it.especial?.toString().orEmpty())
        }

        val dialogo = MaterialAlertDialogBuilder(contexto)
            .setTitle(if (actual == null) "Nueva asignatura" else "Editar asignatura")
            .setView(d.root)
            .setPositiveButton("Guardar", null)
            .setNegativeButton("Cancelar", null)
            .create()

        dialogo.setOnShowListener {
            dialogo.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val nombre = d.etNombre.text.toString().trim()
                val semestre = d.menuSemestre.text.toString().toIntOrNull()
                val n = d.etNormal.text.toString()
                val r = d.etRepeticion.text.toString()
                val e = d.etEspecial.text.toString()

                d.tilNombre.error = if (nombre.isEmpty()) "Requerido" else null
                d.tilSemestre.error = if (semestre == null) "Elige un semestre" else null
                d.tilNormal.error = if (notaValida(n)) null else "0 a 100"
                d.tilRepeticion.error = if (notaValida(r)) null else "0 a 100"
                d.tilEspecial.error = if (notaValida(e)) null else "0 a 100"

                val hayError = listOf(d.tilNombre, d.tilSemestre, d.tilNormal, d.tilRepeticion, d.tilEspecial)
                    .any { it.error != null }
                if (hayError || semestre == null) return@setOnClickListener

                alGuardar(
                    Asignatura(
                        id = actual?.id ?: 0,
                        nombre = nombre,
                        semestre = semestre,
                        normal = leerNota(n),
                        repeticion = leerNota(r),
                        especial = leerNota(e)
                    )
                )
                dialogo.dismiss()
            }
        }
        dialogo.show()
    }
}
