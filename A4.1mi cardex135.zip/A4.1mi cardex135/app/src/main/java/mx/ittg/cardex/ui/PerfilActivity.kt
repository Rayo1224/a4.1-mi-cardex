package mx.ittg.cardex.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import mx.ittg.cardex.data.Sesion
import mx.ittg.cardex.databinding.ActivityPerfilBinding

/** Pantalla de inicio de sesión: nombre completo y número de control. Solo se usa la primera vez. */
class PerfilActivity : AppCompatActivity() {

    private lateinit var b: ActivityPerfilBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Si ya inició sesión, no se pueden modificar los datos: se va directo al cardex
        if (Sesion.registrado(this)) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        b = ActivityPerfilBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnGuardar.setOnClickListener {
            val nombre = b.etNombre.text.toString().trim().replace(Regex("\\s+"), " ")
            val control = b.etControl.text.toString().trim()
            b.tilNombre.error =
                if (nombre.split(" ").size < 2) "Escribe tu nombre completo (nombre y apellidos)" else null
            b.tilControl.error = if (control.isEmpty()) "Escribe tu número de control" else null
            if (b.tilNombre.error != null || b.tilControl.error != null) return@setOnClickListener

            MaterialAlertDialogBuilder(this)
                .setTitle("¿Confirmar datos?")
                .setMessage("$nombre\nNo. control: $control\n\nNo podrás modificarlos después.")
                .setPositiveButton("Sí, entrar") { _, _ ->
                    Sesion.guardar(this, nombre, control)
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }
                .setNegativeButton("Revisar", null)
                .show()
        }
    }
}
