package mx.ittg.cardex.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Única tabla de la base de datos: una fila por asignatura. */
@Entity(tableName = "asignaturas")
data class Asignatura(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val semestre: Int,
    val normal: Double?,
    val repeticion: Double?,
    val especial: Double?
) {
    /** Calificación vigente: la de la última oportunidad registrada. */
    fun vigente(): Double? = especial ?: repeticion ?: normal
}

/** Resultado de la consulta de promedio por semestre. */
data class PromSem(val semestre: Int, val promedio: Double)
