package mx.ittg.cardex.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface AsignaturaDao {

    @Query("SELECT * FROM asignaturas ORDER BY semestre, nombre")
    fun observarTodas(): LiveData<List<Asignatura>>

    @Insert
    suspend fun insertar(a: Asignatura)

    @Update
    suspend fun actualizar(a: Asignatura)

    @Delete
    suspend fun borrar(a: Asignatura)

    @Query(
        """SELECT AVG(CASE WHEN especial IS NOT NULL THEN especial
                           WHEN repeticion IS NOT NULL THEN repeticion
                           ELSE normal END)
           FROM asignaturas"""
    )
    fun observarPromedioGeneral(): LiveData<Double?>

    @Query(
        """SELECT semestre,
                  AVG(CASE WHEN especial IS NOT NULL THEN especial
                           WHEN repeticion IS NOT NULL THEN repeticion
                           ELSE normal END) AS promedio
           FROM asignaturas
           GROUP BY semestre
           HAVING promedio IS NOT NULL
           ORDER BY semestre"""
    )
    fun observarPromediosSemestre(): LiveData<List<PromSem>>
}
