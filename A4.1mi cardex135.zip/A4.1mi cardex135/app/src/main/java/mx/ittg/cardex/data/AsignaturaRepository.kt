package mx.ittg.cardex.data

import androidx.lifecycle.LiveData

/** Intermediario entre el ViewModel y el DAO: el ViewModel nunca toca la base de datos directamente. */
class AsignaturaRepository(private val dao: AsignaturaDao) {

    val asignaturas: LiveData<List<Asignatura>> = dao.observarTodas()
    val promedioGeneral: LiveData<Double?> = dao.observarPromedioGeneral()
    val promediosSemestre: LiveData<List<PromSem>> = dao.observarPromediosSemestre()

    /** Si la asignatura es nueva (id = 0) la inserta; si ya existe, la actualiza. */
    suspend fun guardar(a: Asignatura) {
        if (a.id == 0L) dao.insertar(a) else dao.actualizar(a)
    }

    suspend fun borrar(a: Asignatura) = dao.borrar(a)
}
