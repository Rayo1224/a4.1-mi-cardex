package mx.ittg.cardex.data

import android.content.Context
import androidx.core.content.edit

/** Nombre y número de control del alumno, guardados con SharedPreferences. */
object Sesion {
    private const val ARCHIVO = "datos_alumno"

    private fun prefs(c: Context) = c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)

    fun nombre(c: Context): String = prefs(c).getString("nombre", "").orEmpty()
    fun control(c: Context): String = prefs(c).getString("control", "").orEmpty()

    /** Solo guarda la primera vez: una vez registrados, el nombre y el control ya no se modifican. */
    fun guardar(c: Context, nombre: String, control: String) {
        if (registrado(c)) return
        prefs(c).edit {
            putString("nombre", nombre)
            putString("control", control)
        }
    }

    fun registrado(c: Context) = nombre(c).isNotBlank() && control(c).isNotBlank()
}
