package mx.ittg.cardex.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import mx.ittg.cardex.data.Asignatura
import mx.ittg.cardex.databinding.FragmentListaBinding

class ListaFragment : Fragment() {

    private var _b: FragmentListaBinding? = null
    private val b get() = _b!!
    private val vm: CardexViewModel by activityViewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        _b = FragmentListaBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val adapter = AsignaturaAdapter(
            alTocar = { abrirFormulario(it) },
            alMantener = { confirmarBorrado(it) }
        )
        b.lista.layoutManager = LinearLayoutManager(requireContext())
        b.lista.adapter = adapter

        vm.filas.observe(viewLifecycleOwner) { datos ->
            adapter.submitList(datos)
            b.vacio.isVisible = datos.isEmpty()
        }
        b.fabNuevo.setOnClickListener { abrirFormulario(null) }
    }

    private fun abrirFormulario(actual: Asignatura?) {
        FormularioAsignatura.mostrar(requireContext(), layoutInflater, actual) { nueva ->
            vm.guardar(nueva)
        }
    }

    private fun confirmarBorrado(a: Asignatura) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Eliminar asignatura")
            .setMessage("¿Eliminar \"${a.nombre}\" de tu cardex?")
            .setPositiveButton("Eliminar") { _, _ -> vm.borrar(a) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}
